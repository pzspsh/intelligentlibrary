# LaWGPT：基于中文法律知识的大语言模型

<p align="center">
  <a href="assets/logo/lawgpt.jpeg">
    <img src="./assets/logo/lawgpt.jpeg" width="80%" >
  </a>
</p>

<p align="center">
    <a href="https://github.com/pengxiao-song/LaWGPT/wiki"><img src="https://img.shields.io/badge/docs-Wiki-brightgreen"></a>
    <a href="https://huggingface.co/entity303"><img src="https://img.shields.io/badge/Hugging%20Face-entity303-green"></a>
    <a href=""><img src="https://img.shields.io/badge/version-beta1.1-blue"></a>
    <a href=""><img src="https://img.shields.io/badge/os-Linux-9cf"></a>
    <a href=""><img src="https://img.shields.io/github/last-commit/pengxiao-song/lawgpt"></a>
    <a href="https://star-history.com/#pengxiao-song/LaWGPT&Timeline"><img src="https://img.shields.io/github/stars/pengxiao-song/lawgpt?color=yellow"></a> 
    <!-- <a href="https://www.lamda.nju.edu.cn/"><img src="https://img.shields.io/badge/support-NJU--LAMDA-9cf.svg"></a> -->
</p>

LaWGPT 是一系列基于中文法律知识的开源大语言模型。

该系列模型在通用中文基座模型（如 Chinese-LLaMA、ChatGLM 等）的基础上扩充法律领域专有词表、**大规模中文法律语料预训练**，增强了大模型在法律领域的基础语义理解能力。在此基础上，**构造法律领域对话问答数据集、中国司法考试数据集进行指令精调**，提升了模型对法律内容的理解和执行能力。

详细内容请参考[技术报告]()。

---

本项目持续开展，法律领域数据集及系列模型后续相继开源，敬请关注。

## 更新

- 🌟 2023/05/30：公开发布
  <a href="https://huggingface.co/entity303/lawgpt-lora-7b-v2"><img src="https://img.shields.io/badge/Model-LaWGPT--7B--beta1.1-yellow"></a>
 
  - **LaWGPT-7B-beta1.1**：法律对话模型，构造 35w 高质量法律问答数据集基于 Chinese-alpaca-plus-7B 指令精调

- 📣 2023/05/26：开放 [Discussions 讨论区](https://github.com/pengxiao-song/LaWGPT/discussions)，欢迎朋友们交流探讨、提出意见、分享观点！

- 🛠️ 2023/05/22：项目主分支结构调整，详见[项目结构](https://github.com/pengxiao-song/LaWGPT#项目结构)；支持[命令行批量推理](https://github.com/pengxiao-song/LaWGPT/blob/main/scripts/infer.sh)

- 🪴 2023/05/15：发布 [中文法律数据源汇总（Awesome Chinese Legal Resources）](https://github.com/pengxiao-song/awesome-chinese-legal-resources) 和 [法律领域词表](https://github.com/pengxiao-song/LaWGPT/blob/main/resources/legal_vocab.txt)

- 🌟 2023/05/13：公开发布
  <a href="https://huggingface.co/entity303/legal-lora-7b"><img src="https://img.shields.io/badge/Model-Legal--Base--7B-blue"></a> 
  <a href="https://huggingface.co/entity303/lawgpt-legal-lora-7b"><img src="https://img.shields.io/badge/Model-LaWGPT--7B--beta1.0-yellow"></a>
  
  - **Legal-Base-7B**：法律基座模型，使用 50w 中文裁判文书数据二次预训练
  
  - **LaWGPT-7B-beta1.0**：法律对话模型，构造 30w 高质量法律问答数据集基于 Legal-Base-7B 指令精调
  
- 🌟 2023/04/12：内部测试
  <a href="https://huggingface.co/entity303/lawgpt-lora-7b"><img src="https://img.shields.io/badge/Model-Lawgpt--7B--alpha-yellow"></a>
  - **LaWGPT-7B-alpha**：在 Chinese-LLaMA-7B 的基础上直接构造 30w 法律问答数据集指令精调

## 快速开始

1. 准备代码，创建环境

   ```bash
   # 下载代码
   git clone git@github.com:pengxiao-song/LaWGPT.git
   cd LaWGPT

   # 创建环境
   conda create -n lawgpt python=3.10 -y
   conda activate lawgpt
   pip install -r requirements.txt
   ```
2. **启动 web ui（可选，易于调节参数）**

   - 首先，执行服务启动脚本：`bash scripts/webui.sh`

   - 其次，访问 http://127.0.0.1:7860 ：

   <p align="center">
      <img style="border-radius: 50%; box-shadow: 0 0 10px rgba(0,0,0,0.5); width: 80%;", src="./assets/demo/example-03.jpeg">
   </p>
   
3. **命令行推理（可选，支持批量测试）**

   - 首先，参考 `resources/example_infer_data.json` 文件内容构造测试样本集；
   
   - 其次，执行推理脚本：`bash scripts/infer.sh`。其中 `--infer_data_path` 参数为测试样本集路径，如果为空或者路径出错，则以交互模式运行。

注意，以上步骤的默认模型为 LaWGPT-7B-alpha ，如果您想使用 LaWGPT-7B-beta1.0 模型：

- 由于 [LLaMA](https://github.com/facebookresearch/llama) 和 [Chinese-LLaMA](https://github.com/ymcui/Chinese-LLaMA-Alpaca) 均未开源模型权重。根据相应开源许可，**本项目只能发布 LoRA 权重**，无法发布完整的模型权重，请各位谅解。

- 本项目给出[合并方式](https://github.com/pengxiao-song/LaWGPT/wiki/%E6%A8%A1%E5%9E%8B%E5%90%88%E5%B9%B6)，请各位获取原版权重后自行重构模型。


## 项目结构

```bash    
LaWGPT
├── assets    # 静态资源
├── resources # 项目资源
├── models    # 基座模型及 lora 权重
│   ├── base_models
│   └── lora_weights
├── outputs   # 指令微调的输出权重
├── data      # 实验数据
├── scripts   # 脚本目录
│   ├── finetune.sh # 指令微调脚本
│   └── webui.sh    # 启动服务脚本
├── templates # prompt 模板
├── tools     # 工具包
├── utils
├── train_clm.py  # 二次训练
├── finetune.py   # 指令微调
├── webui.py      # 启动服务
├── README.md
└── requirements.txt
```


## 数据构建

本项目基于中文裁判文书网公开法律文书数据、司法考试数据等数据集展开，详情参考[中文法律数据源汇总（Awesome Chinese Legal Resources）](https://github.com/pengxiao-song/awesome-chinese-legal-resources)。

1. 初级数据生成：根据 [Stanford_alpaca](https://github.com/tatsu-lab/stanford_alpaca#data-generation-process) 和 [self-instruct](https://github.com/yizhongw/self-instruct) 方式生成对话问答数据
2. 知识引导的数据生成：通过 Knowledge-based Self-Instruct 方式基于中文法律结构化知识生成数据。
3. 引入 ChatGPT 清洗数据，辅助构造高质量数据集。

## 模型训练

LawGPT 系列模型的训练过程分为两个阶段：

1.  第一阶段：扩充法律领域词表，在大规模法律文书及法典数据上预训练 Chinese-LLaMA
2.  第二阶段：构造法律领域对话问答数据集，在预训练模型基础上指令精调

### 二次训练流程

1. 参考 `resources/example_instruction_train.json` 构造二次训练数据集
2. 运行 `scripts/train_clm.sh` 

### 指令精调步骤

1. 参考 `resources/example_instruction_tune.json` 构造指令微调数据集
2. 运行 `scripts/finetune.sh` 

### 计算资源

8 张 Tesla V100-SXM2-32GB ：二次训练阶段耗时约 24h / epoch，微调阶段耗时约 12h / epoch

## 模型评估

### 输出示例

<details><summary>问题：酒驾撞人怎么判刑？</summary>

![](assets/demo/demo07.jpeg)

</details>

<details><summary>问题：请给出判决意见。</summary>

![](assets/demo/example-05.jpeg)

</details>

<details><summary>问题：请介绍赌博罪的定义。</summary>

![](assets/demo/example-06.jpeg)

</details>

<details><summary>问题：请问加班工资怎么算？</summary>

![](assets/demo/example-04.jpeg)

</details>

<details><summary>问题：民间借贷受国家保护的合法利息是多少?</summary>

![](assets/demo/example-02.jpeg)

</details>

<details><summary>问题：欠了信用卡的钱还不上要坐牢吗？</summary>

![](assets/demo/example-01.jpeg)

</details>

<details><summary>问题：你能否写一段抢劫罪罪名的案情描述？</summary>

![](assets/demo/example-03.jpeg)

</details>


### 局限性

由于计算资源、数据规模等因素限制，当前阶段 LawGPT 存在诸多局限性：

1. 数据资源有限、模型容量较小，导致其相对较弱的模型记忆和语言能力。因此，在面对事实性知识任务时，可能会生成不正确的结果。
2. 该系列模型只进行了初步的人类意图对齐。因此，可能产生不可预测的有害内容以及不符合人类偏好和价值观的内容。
3. 自我认知能力存在问题，中文理解能力有待增强。

请诸君在使用前了解上述问题，以免造成误解和不必要的麻烦。


## 协作者

如下各位合作开展（按字母序排列）：[@cainiao](https://github.com/herobrine19)、[@njuyxw](https://github.com/njuyxw)、[@pengxiao-song](https://github.com/pengxiao-song)


## 免责声明

请各位严格遵守如下约定：

1. 本项目任何资源**仅供学术研究使用，严禁任何商业用途**。
2. 模型输出受多种不确定性因素影响，本项目当前无法保证其准确性，**严禁用于真实法律场景**。
3. 本项目不承担任何法律责任，亦不对因使用相关资源和输出结果而可能产生的任何损失承担责任。


## 问题反馈

如有问题，请在 GitHub Issue 中提交。

- 提交问题之前，建议查阅 FAQ 及以往的 issue 看是否能解决您的问题。
- 请礼貌讨论，构建和谐社区。

协作者科研之余推进项目进展，由于人力有限难以实时反馈，给诸君带来不便，敬请谅解！


## 致谢

本项目基于如下开源项目展开，在此对相关项目和开发人员表示诚挚的感谢：

- Chinese-LLaMA-Alpaca: https://github.com/ymcui/Chinese-LLaMA-Alpaca
- LLaMA: https://github.com/facebookresearch/llama
- Alpaca: https://github.com/tatsu-lab/stanford_alpaca
- alpaca-lora: https://github.com/tloen/alpaca-lora
- ChatGLM-6B: https://github.com/THUDM/ChatGLM-6B

此外，本项目基于开放数据资源，详见 [Awesome Chinese Legal Resources](https://github.com/pengxiao-song/awesome-chinese-legal-resources)，一并表示感谢。


## 引用

如果您觉得我们的工作对您有所帮助，请考虑引用该项目
